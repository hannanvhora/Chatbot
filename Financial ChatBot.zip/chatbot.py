from flask import Flask, request, render_template_string

app = Flask(__name__)

# Predefined responses
responses = {
    "What is the total revenue?": "The total revenue is $1,000,000.",
    "How has net income changed over the last year?": "The net income has increased by $20,000 over the last year.",
    "What are the main expenses?": "The main expenses are salaries and marketing, totaling $500,000.",
    "What is the profit margin?": "The profit margin is 20%."
}

# HTML Template (very simple chat UI)
html_template = """
<!DOCTYPE html>
<html>
<head>
    <title>Financial Chatbot</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; }
        .chat-box { width: 400px; margin: auto; }
        .message { margin: 10px 0; }
        .user { color: blue; }
        .bot { color: green; }
    </style>
</head>
<body>
    <div class="chat-box">
        <h2>Financial Chatbot</h2>
        <form method="POST">
            <input type="text" name="query" placeholder="Ask a question..." style="width:80%" required>
            <button type="submit">Send</button>
        </form>
        {% if user_query %}
            <div class="message user"><b>You:</b> {{ user_query }}</div>
            <div class="message bot"><b>Bot:</b> {{ bot_response }}</div>
        {% endif %}
    </div>
</body>
</html>
"""

@app.route("/", methods=["GET", "POST"])
def chatbot():
    user_query = None
    bot_response = None
    if request.method == "POST":
        user_query = request.form["query"]
        bot_response = responses.get(user_query, "Sorry, I can only answer predefined queries.")
    return render_template_string(html_template, user_query=user_query, bot_response=bot_response)

if __name__ == "__main__":
    app.run(debug=True)
