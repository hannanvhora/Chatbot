from flask import Flask, render_template, request, redirect, url_for
import pandas as pd
import re
import spacy
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

app = Flask(__name__)

# Load NLP model (ensure en_core_web_sm is installed)
# python -m spacy download en_core_web_sm
nlp = spacy.load("en_core_web_sm")

# Chat history with updated first message
chat_history = [
    {
        "user": "",
        "bot": "Hello, here is your financial assistance. How can I help you?\n"
               "Upload your CSV file for more accurate results.",
        "followups": []
    }
]

data = None  # global storage for CSV
vectorizer = TfidfVectorizer()

# --------- ML/NLP globals ----------
qa_corpus = []     # list[str] - synthetic questions
qa_answers = []    # list[str] - answer strings aligned with qa_corpus
qa_meta = []       # list[dict] - metadata per item (company, year, metric)
qa_matrix = None   # TF-IDF matrix


def suggest_questions(df):
    """Generate example questions from CSV columns and values"""
    suggestions = []
    if "Company" in df.columns and "year" in df.columns:
        companies = df["Company"].dropna().unique()[:2]  # pick first 2
        years = df["year"].dropna().unique()[:2]  # pick first 2
        if len(companies) > 0 and len(years) > 0:
            comp = companies[0]
            try:
                yr = int(years[0])
            except:
                yr = years[0]
            suggestions.append(f"What was {comp}'s Total Revenue in {yr}?")
            if len(companies) > 1:
                suggestions.append(f"Compare {companies[0]} and {companies[1]}'s Total Revenue in {yr}")
            suggestions.append(f"Show me {comp}'s Net Income trend over the years")
            try:
                last_yr = int(years[-1])
            except:
                last_yr = years[-1]
            suggestions.append(f"How did {comp}'s Total Revenue change between {yr} and {last_yr}?")
    return suggestions


def generate_followups(user_message):
    """Generate follow-up questions dynamically"""
    followups = []
    msg = user_message.lower()

    company = None
    if "apple" in msg:
        company = "Apple"
    elif "microsoft" in msg:
        company = "Microsoft"
    elif "tesla" in msg:
        company = "Tesla"

    year = None
    year_match = re.search(r"\b(20\d{2})\b", msg)
    if year_match:
        year = year_match.group(1)

    if company and year:
        followups = [
            f"Would you like to see {company}'s net income in {year}?",
            f"Do you want {company}'s profit margin for {year}?",
            f"Should I compare {company}'s {year} data with another company?"
        ]
    elif company:
        followups = [
            f"Do you want to see {company}'s revenue year by year?",
            f"Would you like {company}'s profit margin details?",
            f"Should I compare {company} with another company?"
        ]
    else:
        followups = [
            "Would you like a year-by-year revenue trend?",
            "Should I show profit margin comparisons?",
            "Do you want insights on net income growth?"
        ]

    return followups


# ---------------- ML/NLP helpers ----------------

def build_qa_index(df):
    """
    Create a semantic QA index from the CSV.
    For each (Company, year, metric) cell, generate several phrasings and store the answer.
    """
    global qa_corpus, qa_answers, qa_meta, qa_matrix, vectorizer

    qa_corpus, qa_answers, qa_meta = [], [], []

    # require at least Company & year to build meaningful QA pairs
    if "Company" not in df.columns or "year" not in df.columns:
        qa_matrix = None
        return

    # Treat all columns except Company/year as metrics
    metric_cols = [c for c in df.columns if c not in ["Company", "year"]]

    for _, row in df.iterrows():
        # skip rows lacking Company/year
        if pd.isna(row.get("Company")) or pd.isna(row.get("year")):
            continue
        company = str(row["Company"])
        year = str(row["year"])
        for metric in metric_cols:
            if metric not in row or pd.isna(row[metric]):
                continue
            val = row[metric]
            # Format value nicely
            try:
                # numeric formatting
                if isinstance(val, (int, float)):
                    value_str = f"{val:,}"
                else:
                    value_str = str(val)
            except:
                value_str = str(val)

            # canonical answer
            ans = f"{company}'s {metric} in {year} was {value_str}"

            # paraphrased templates
            q_templates = [
                f"What was {company}'s {metric} in {year}?",
                f"{company} {metric} {year}",
                f"Show {company}'s {metric} for {year}",
                f"In {year}, what is {company}'s {metric}?",
                f"Give me {company} {metric} for {year}",
                f"{metric} of {company} in {year}",
                f"How much was {company}'s {metric} in {year}?"
            ]

            for q in q_templates:
                qa_corpus.append(q.lower())
                qa_answers.append(ans)
                qa_meta.append({"company": company, "year": year, "metric": metric})

    if qa_corpus:
        qa_matrix = vectorizer.fit_transform(qa_corpus)
    else:
        qa_matrix = None


def nlp_extract(user_message, df):
    """
    Use spaCy to pull ORG (company) and DATE (year) hints from the user message.
    Falls back to string matching against Company column.
    """
    doc = nlp(user_message)

    # Candidate company by ORG or PRODUCT
    company = None
    org_ents = [ent.text for ent in doc.ents if ent.label_ in ("ORG", "PRODUCT")]
    if org_ents:
        lower_msg = user_message.lower()
        # try exact substring against known companies first
        for c in df["Company"].dropna().unique():
            if str(c).lower() in lower_msg:
                company = str(c)
                break
        if not company:
            # fuzzy-ish: match org entity with company names
            companies_lower = [str(c).lower() for c in df["Company"].dropna().unique()]
            for org in org_ents:
                lo = org.lower()
                matches = [c for c in companies_lower if lo in c or c in lo]
                if matches:
                    idx = companies_lower.index(matches[0])
                    company = str(df["Company"].dropna().unique()[idx])
                    break

    # Candidate year
    year = None
    year_match = re.search(r"\b(20\d{2})\b", user_message)
    if year_match:
        year = year_match.group(1)
    else:
        for ent in doc.ents:
            if ent.label_ == "DATE":
                ym = re.search(r"\b(20\d{2})\b", ent.text)
                if ym:
                    year = ym.group(1)
                    break

    return company, year


def ml_similarity_answer(user_message):
    """
    Use TF-IDF + cosine similarity to find the best matching Q and return its answer.
    Returns (answer, score) or (None, 0).
    """
    global qa_matrix, qa_corpus, qa_answers, vectorizer
    if qa_matrix is None or not qa_corpus:
        return None, 0.0

    query_vec = vectorizer.transform([user_message.lower()])
    sims = cosine_similarity(query_vec, qa_matrix).ravel()
    idx = sims.argmax()
    score = float(sims[idx])

    # Threshold - adjust if you need more/less permissive matching
    if score >= 0.25:
        return qa_answers[idx], score
    return None, score


# ---------------- hybrid answer logic ----------------

def answer_question(user_message, df):
    """
    Hybrid answering:
      1) Rule-based exact lookup (Company + year + metric).
      2) NLP entity extraction assists rule-based.
      3) ML TF-IDF semantic fallback to nearest synthetic Q.
    """
    lower_msg = user_message.lower()

    # --- (A) Try to extract with simple rules + NLP assist ---
    company_rb = None
    # try direct substring match against companies
    if "Company" in df.columns:
        for c in df["Company"].dropna().unique():
            if str(c).lower() in lower_msg:
                company_rb = str(c)
                break

    year_rb = None
    m = re.search(r"\b(20\d{2})\b", lower_msg)
    if m:
        year_rb = m.group(1)

    # NLP hints
    company_nlp, year_nlp = (None, None)
    try:
        company_nlp, year_nlp = nlp_extract(user_message, df)
    except Exception:
        # spaCy extraction failed — ignore and continue with rule-based
        company_nlp, year_nlp = None, None

    company = company_rb or company_nlp
    year = year_rb or year_nlp

    # Determine metric from text or column match
    metric = None
    metric_cols = [c for c in df.columns if c not in ["Company", "year"]]

    # direct column name mention
    for col in metric_cols:
        if col.lower() in lower_msg:
            metric = col
            break

    # loose keywords → columns
    if not metric:
        keywords = {
            "revenue": ["total revenue", "revenue", "top line", "sales"],
            "income": ["net income", "income", "profit"],
            "profit margin": ["profit margin", "margin", "profit %", "gross margin", "operating margin"],
            "eps": ["eps", "earnings per share"],
            "cash": ["cash", "cash flow", "operating cash flow", "free cash flow"]
        }
        for key, alts in keywords.items():
            if any(k in lower_msg for k in alts):
                candidates = [c for c in metric_cols if any(a in c.lower() for a in alts)]
                if candidates:
                    metric = candidates[0]
                    break
        if not metric and any(k in lower_msg for k in ["revenue", "sales", "top line"]):
            metric = "Total Revenue" if "Total Revenue" in df.columns else None

    # (A1) Exact lookup if we have company + year (+ metric optional)
    if company and year:
        # guard: ensure 'year' column exists
        if "year" in df.columns and "Company" in df.columns:
            row = df[
                (df["Company"].astype(str).str.lower() == company.lower()) &
                (df["year"].astype(str) == str(year))
            ]
            if not row.empty:
                if metric and metric in df.columns:
                    val = row.iloc[0][metric]
                    try:
                        value_str = f"{val:,}" if isinstance(val, (int, float)) else str(val)
                    except:
                        value_str = str(val)
                    return f"{company}'s {metric} in {year} was {value_str}"
                else:
                    # If metric missing, show all metric columns for that year
                    available_metrics = [c for c in metric_cols if c in row.columns]
                    if available_metrics:
                        pieces = []
                        for c in available_metrics:
                            v = row.iloc[0][c]
                            try:
                                vs = f"{v:,}" if isinstance(v, (int, float)) else str(v)
                            except:
                                vs = str(v)
                            pieces.append(f"{c}: {vs}")
                        return f"{company} in {year} — " + "; ".join(pieces)

    # (A2) If company but no year and a metric → show trend (year by year)
    if company and metric and metric in df.columns and "year" in df.columns:
        rows = df[df["Company"].astype(str).str.lower() == company.lower()][["year", metric]].dropna()
        if not rows.empty:
            # sort by year if numeric
            try:
                rows_sorted = rows.copy()
                rows_sorted["year_int"] = rows_sorted["year"].astype(int)
                rows_sorted = rows_sorted.sort_values("year_int")
            except Exception:
                rows_sorted = rows
            trend_pieces = []
            for _, r in rows_sorted.iterrows():
                y = r["year"]
                v = r[metric]
                try:
                    vs = f"{v:,}" if isinstance(v, (int, float)) else str(v)
                except:
                    vs = str(v)
                trend_pieces.append(f"{y}: {vs}")
            return f"{company}'s {metric} over the years — " + "; ".join(trend_pieces)

    # (A3) If user asked to compare two companies in same year (very basic parse)
    # e.g., "Compare Apple and Microsoft's Total Revenue in 2022"
    if "compare" in lower_msg and "and" in lower_msg and "year" not in lower_msg:
        # try to extract two companies by splitting tokens around 'and'
        tokens = lower_msg.replace("'", "").split()
        # naive company extraction — fallback to ML below if this doesn't match
        # skip advanced compare here; fall through to ML similarity as fallback.

        pass

    # --- (B) ML similarity fallback ---
    try:
        ml_ans, score = ml_similarity_answer(user_message)
        if ml_ans:
            return ml_ans
    except Exception:
        # TF-IDF or similarity failed — ignore and fallback
        pass

    # --- (C) Graceful fallback ---
    if not data:
        return "I don’t have enough data yet. Please upload a CSV first."
    return "I understood your question, but I need more details or matching data from the CSV."


# ---------------- routes ----------------

@app.route("/", methods=["GET"])
def index():
    return render_template("ondex.html", chat_history=chat_history)


@app.route("/upload", methods=["POST"])
def upload():
    global data, chat_history
    file = request.files.get("file")
    if file and file.filename.endswith(".csv"):
        try:
            data = pd.read_csv(file)
        except Exception as e:
            chat_history.append({
                "user": "Uploaded CSV file.",
                "bot": f"Error reading CSV: {e}",
                "followups": []
            })
            return redirect(url_for("index"))

        # Build ML/NLP QA index from the CSV
        try:
            build_qa_index(data)
        except Exception:
            # non-fatal: continue without ML index
            pass

        # Generate suggestions after CSV load
        suggestions = suggest_questions(data)

        chat_history.append({
            "user": "Uploaded CSV file.",
            "bot": "✅ CSV uploaded successfully! Here are some questions you can ask:",
            "followups": suggestions
        })
    else:
        chat_history.append({
            "user": "Attempted upload",
            "bot": "Please upload a valid .csv file.",
            "followups": []
        })
    return redirect(url_for("index"))


@app.route("/ask", methods=["POST"])
def ask():
    global chat_history, data
    user_message = request.form.get("message", "").strip()
    if not user_message:
        return redirect(url_for("index"))

    if data is not None:
        bot_reply = answer_question(user_message, data)
    else:
        bot_reply = "I don’t have enough data yet. Please upload a CSV first."

    followups = generate_followups(user_message)

    chat_history.append({"user": user_message, "bot": bot_reply, "followups": followups})

    return redirect(url_for("index"))


if __name__ == "__main__":
    app.run(debug=True)
